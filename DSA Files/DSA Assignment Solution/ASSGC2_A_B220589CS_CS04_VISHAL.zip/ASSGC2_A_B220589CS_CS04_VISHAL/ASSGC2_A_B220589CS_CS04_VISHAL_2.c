#include <stdio.h>
#include <stdlib.h>

struct Node {
    int Value;
    int Key;
    int Height;
    struct Node* Left;
    struct Node* Right;
   
} ;


int Height(struct Node* node) {
    if (node == NULL)
        return 0;
    return node->Height;
}


int max(int a, int b) {
    return (a > b) ? a : b;
}

struct Node* createNode(int Key, int Value) {
    struct Node* node = (struct Node*)malloc(sizeof(struct Node));
    node->Key = Key;
    node->Value = Value;
    node->Left = NULL;
    node->Right = NULL;
    node->Height = 1;
    return node;
}

struct Node* left_Rotate(struct Node* u) {
    struct Node* v = u->Right;
    struct Node* Tt = v->Left;

    v->Left = u;
    u->Right = Tt;

    u->Height = max(Height(u->Left), Height(u->Right)) + 1;
    v->Height = max(Height(v->Left), Height(v->Right)) + 1;

    return v;
}


struct Node* right_Rotate(struct Node* v) {
    struct Node* u = v->Left;
    struct Node* Tt = u->Right;

    u->Right = v;
    v->Left = Tt;

    v->Height = max(Height(v->Left), Height(v->Right)) + 1;
    u->Height = max(Height(u->Left), Height(u->Right)) + 1;

    return u;
}



int find_BalanceF(struct Node* node) {
    if (node == NULL)
        return 0;
    return Height(node->Left) - Height(node->Right);
}

struct Node* Insert(struct Node* node, int Key, int Value) {
    if (node == NULL)
        return createNode(Key, Value);

    if (Key < node->Key)
        node->Left = Insert(node->Left, Key, Value);
    else if (Key > node->Key)
        node->Right = Insert(node->Right, Key, Value);
    else {
        // Update Value if Key already exists
        node->Value = Value;
        return node;
    }

    node->Height = 1 + max(Height(node->Left), Height(node->Right));

    int balance = find_BalanceF(node);

    // Left Left Case
    if (balance > 1 && Key < node->Left->Key)
        return right_Rotate(node);

    // Right Right Case
    if (balance < -1 && Key > node->Right->Key)
        return left_Rotate(node);

    // Left Right Case
    if (balance > 1 && Key > node->Left->Key) {
        node->Left = left_Rotate(node->Left);
        return right_Rotate(node);
    }

    // Right Left Case
    if (balance < -1 && Key < node->Right->Key) {
        node->Right = right_Rotate(node->Right);
        return left_Rotate(node);
    }

    return node;
}

struct Node* minValue_Node(struct Node* node) {
    struct Node* current = node;

    while (current && current->Left != NULL)
        current = current->Left;

    return current;
}

struct Node* delete_Node(struct Node* root, int Key) {
    if (root == NULL)
        return root;

    if (Key < root->Key)
        root->Left = delete_Node(root->Left, Key);
    else if (Key > root->Key)
        root->Right = delete_Node(root->Right, Key);
    else {
        if ((root->Left == NULL) || (root->Right == NULL)) {
            struct Node* temp = root->Left ? root->Left : root->Right;

            if (temp == NULL) {
                temp = root;
                root = NULL;
            } else
                *root = *temp;

            free(temp);
        } else {
            struct Node* temp = minValue_Node(root->Right);

            root->Key = temp->Key;
            root->Value = temp->Value;

            root->Right = delete_Node(root->Right, temp->Key);
        }
    }

    if (root == NULL)
        return root;

    root->Height = 1 + max(Height(root->Left), Height(root->Right));

    int balance = find_BalanceF(root);

    // Left Left Case
    if (balance > 1 && find_BalanceF(root->Left) >= 0)
        return right_Rotate(root);

    // Left Right Case
    if (balance > 1 && find_BalanceF(root->Left) < 0) {
        root->Left = left_Rotate(root->Left);
        return right_Rotate(root);
    }

    // Right Right Case
    if (balance < -1 && find_BalanceF(root->Right) <= 0)
        return left_Rotate(root);

    // Right Left Case
    if (balance < -1 && find_BalanceF(root->Right) > 0) {
        root->Right = right_Rotate(root->Right);
        return left_Rotate(root);
    }

    return root;
}

void Find(struct Node* root, int Key) {
    struct Node* current = root;

    while (current != NULL) {
        if (current->Key == Key) {
            printf("%d %d\n", current->Key, current->Value);
            return;
        } else if (current->Key < Key)
            current = current->Right;
        else
            current = current->Left;
    }

    printf("-1\n");
}

void Lower_Bound(struct Node* root, int Key) {
    struct Node* current = root;
    struct Node* result = NULL;

    while (current != NULL) {
        if (current->Key >= Key) {
            result = current;
            current = current->Left;
        } else
            current = current->Right;
    }

    if (result != NULL)
        printf("%d %d\n", result->Key, result->Value);
    else
        printf("-1\n");
}


int Empty(struct Node* root) {
    return (root == NULL) ? 1 : 0;
}

int Size(struct Node* root) {
    if (root == NULL)
        return 0;
    return Size(root->Left) + 1 + Size(root->Right);
}


void print_Elements(struct Node* root) {
    if (root == NULL) {
        printf("-1\n");
        return;
    }

    if (root->Left != NULL)
        print_Elements(root->Left);

    printf("%d ", root->Key);

    if (root->Right != NULL)
        print_Elements(root->Right);
}

int main() {
    struct Node* root = NULL;
    char choice;
    int Key, Value;

    while (1) {
        scanf(" %c", &choice);
        switch(choice){
        case't':
            break;

         case'i': 
            scanf("%d %d", &Key, &Value);
            root = Insert(root, Key, Value);
            break;
         case'l':
            scanf("%d", &Key);
            Lower_Bound(root, Key);
            break;
        case'f':
            scanf("%d", &Key);
            Find(root, Key);
            break;
         case's':
            printf("%d\n", Size(root));
            break;
         case'e':
            printf("%d\n", Empty(root));
            break;
         case'p':
            print_Elements(root);
            printf("\n");
            break;
        
        }
    }

    return 0;
}