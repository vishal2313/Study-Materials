#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


struct Node {
    int key;
    char color;
    struct Node *lef, *rig, *par;
};


struct Node* create_Node(int key) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->key = key;
    newNode->lef = newNode->rig = newNode->par = NULL;
    newNode->color = 'R'; // New node is always red
    return newNode;
}


void left_Rotate(struct Node** root, struct Node* x);
void right_Rotate(struct Node** root, struct Node* y); 
void print_RedBlackTree(struct Node* root); 
void fix_Violation(struct Node** root, struct Node* w);
void insert_InRedBlack(struct Node** root, int key);  


int main() {
    struct Node* root = NULL;
    char in[100];
    int key;

    while (1) {
        fgets(in, sizeof(in), stdin);

        if (in[0] == 'e')
            break;

        else {
            key = strtol(in, NULL, 10);
            insert_InRedBlack(&root, key);
            print_RedBlackTree(root);
            printf("\n");
        }
    }
}

void left_Rotate(struct Node** root, struct Node* x) {
    struct Node* y = x->rig;
    x->rig = y->lef;
    if (y->lef != NULL)
        y->lef->par = x;
    y->par = x->par;
    if (x->par == NULL)
        *root = y;
    else if (x == x->par->lef)
        x->par->lef = y;
    else
        x->par->rig = y;
    y->lef = x;
    x->par = y;
}


void right_Rotate(struct Node** root, struct Node* y) {
    struct Node* x = y->lef;
    y->lef = x->rig;
    if (x->rig != NULL)
        x->rig->par = y;
    x->par = y->par;
    if (y->par == NULL)
        *root = x;
    else if (y == y->par->lef)
        y->par->lef = x;
    else
        y->par->rig = x;
    x->rig = y;
    y->par = x;
}


void print_RedBlackTree(struct Node* root) {
    if (root == NULL){
      printf("()");
      return ;
    }
    printf("(%d %c ", root->key, root->color);
    print_RedBlackTree(root->lef);
    print_RedBlackTree(root->rig);
    printf(") ");
}


void fix_Violation(struct Node** root, struct Node* w) {
    while (w != *root && w->par != NULL && w->par->color == 'R') {
        if (w->par == w->par->par->lef) {
            struct Node* y = w->par->par->rig;
            if (y != NULL && y->color == 'R') {
                w->par->color = 'B';
                y->color = 'B';
                w->par->par->color = 'R';
                w = w->par->par;
            } else {
                if (w == w->par->rig) {
                    w = w->par;
                    left_Rotate(root, w);
                }
                w->par->color = 'B';
                w->par->par->color = 'R';
                right_Rotate(root, w->par->par);
            }
        } else {
            struct Node* y = w->par->par->lef;
            if (y != NULL && y->color == 'R') {
                w->par->color = 'B';
                y->color = 'B';
                w->par->par->color = 'R';
                w = w->par->par;
            } else {
                if (w == w->par->lef) {
                    w = w->par;
                    right_Rotate(root, w);
                }
                w->par->color = 'B';
                w->par->par->color = 'R';
                left_Rotate(root, w->par->par);
            }
        }
    }
    (*root)->color = 'B';
}


void insert_InRedBlack(struct Node** root, int key) {
    struct Node* w = create_Node(key);
    struct Node* y = NULL;
    struct Node* x = *root;

    while (x != NULL) {
        y = x;
        if (w->key < x->key)
            x = x->lef;
        else
            x = x->rig;
    }

    w->par = y;
    if (y == NULL)
        *root = w;
    else if (w->key < y->key)
        y->lef = w;
    else
        y->rig = w;

    fix_Violation(root, w);
}
