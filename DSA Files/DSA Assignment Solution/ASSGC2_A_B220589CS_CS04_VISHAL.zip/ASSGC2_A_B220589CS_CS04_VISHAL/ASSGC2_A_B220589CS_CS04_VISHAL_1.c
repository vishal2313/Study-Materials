#include<stdio.h>
#include<stdlib.h>

struct NODE{
    int KEY;
    struct NODE* L;
    struct NODE* R;
    int Height;
};

int Height(struct NODE* node){
    if(node== NULL)
        return 0;
    return node->Height;
}

int max(int w, int z){
    return (w>z) ? w : z;
}

struct NODE* create_Node(int KEY){
    struct NODE* node = (struct NODE*)malloc(sizeof(struct NODE));
    node->KEY = KEY;
    node->L = NULL;
    node->R = NULL;
    node->Height = 1;
    return node;
}

int Check_Bal_Fact(struct NODE* node){
    if(node == NULL)
        return 0;
    return Height(node->L) - Height(node->R);
}

struct NODE* right_Rot(struct NODE* v){
    struct NODE* u = v->L;
    struct NODE* T1 = u->R;

    u->R = v;
    v->L = T1;

    v->Height = max(Height(v->L), Height(v->R)) + 1;
    u->Height = max(Height(u->L), Height(u->R)) + 1;

    return u;
}

struct NODE* left_Rot(struct NODE* v){
    struct NODE* u = v->R;
    struct NODE* T1 = u->L;

    u->L = v;
    v->R = T1;

    v->Height = max(Height(v->L), Height(v->R)) + 1;
    u->Height = max(Height(u->L), Height(u->R)) + 1;

    return u;
}


struct NODE* AVL_insert(struct NODE* node, int KEY, int *w, int *z){
    if(node == NULL)
        return create_Node(KEY);
    if(KEY < node->KEY)
        node->L = AVL_insert(node->L,KEY, w, z);
    else if(KEY > node->KEY)
        node->R = AVL_insert(node->R,KEY, w, z);
    else 
        return node;
    
    node->Height = 1 + max(Height(node->L), Height(node->R));

    int balance = Check_Bal_Fact(node);

    // Left - Left rotation
    if(balance > 1 && KEY < node->L->KEY){
        *w = *w + 1;
        return right_Rot(node);
    }
    
    // Left - Right case
    if(balance > 1 && KEY > node->L->KEY){
        *w = *w + 1;
        *z = *z + 1;
        node->L = left_Rot(node->L);
        return right_Rot(node);
    }

     //Right -Right
     if(balance < -1 && KEY > node->R->KEY){
        *z = *z + 1;
        return left_Rot(node);
    }

    // Right - Left Rotation
    if(balance < -1 && KEY < node->R->KEY){
        *w = *w + 1;
        *z = *z + 1;
        node->R = right_Rot(node->R);
        return left_Rot(node);
    }
    return node;
}

struct NODE* AVL_search(struct NODE* root, int val){
    if(root){
        if(root->KEY == val)
            return root;
        if(val < root->KEY)
            return AVL_search(root->L,val);
        else if(val > root->KEY)
            return AVL_search(root->R,val);
    }
    return NULL;
}

void AVL_find(struct NODE* root, int val){
    struct NODE* temp = AVL_search(root,val);
    struct NODE* node = root;

    if(temp != NULL){
        while(node->KEY != val && node != NULL){
            if(val < node->KEY){
                printf("%d ",node->KEY);
                node = node->L;
            }
            else{
                printf("%d ",node->KEY);
                node = node->R;
            }
        }
        if(node == NULL)
            printf("-1");
        else
            printf("%d ",node->KEY);
    }
    else
        printf("-1");
}

void AVL_cal(struct NODE* node, int *w, int *z){
    printf("%d %d",*z,*w);
}

void AVL_preorder(struct NODE* root){
    if(root){
        printf("%d ",root->KEY);
        AVL_preorder(root->L);
        AVL_preorder(root->R);
    }
}


int main() {
    struct NODE* T1 = NULL;

    int w=0,z=0;
    char option;
    int val;
    while(1) {
        scanf(" %c", &option);
        switch(option){
        case'i':
    
            scanf("%d", &val);
            T1 = AVL_insert(T1, val,&w,&z); 
            break;
        
        case'x':
    
            scanf("%d", &val);
            AVL_find(T1, val);
            printf("\n");
            break;
        
        case's':
            AVL_cal(T1, &w, &z);
            printf("\n");
            break;
        
        case'p':
            AVL_preorder(T1);
            printf("\n");
            break;
        
        default:
            exit(1);
        }
    }
    return 0;
}