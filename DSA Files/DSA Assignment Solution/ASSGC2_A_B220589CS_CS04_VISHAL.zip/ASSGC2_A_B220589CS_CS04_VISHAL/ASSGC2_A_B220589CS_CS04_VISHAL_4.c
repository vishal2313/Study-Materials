#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct Node {
    char Color; 
    int Key;
    struct Node* Lef;
    struct Node* Righ;
};

struct Node* CREATE_Node(int Key, char Color) {
    struct Node* node = (struct Node*)malloc(sizeof(struct Node));
    node->Key = Key;
    node->Color = Color;
    node->Lef = NULL;
    node->Righ = NULL;
    return node;
}


 int validate_RedBlack_Tree(struct Node* node);
 struct Node* paren_Tree(char Tex[], int* ind);

 int main() {

    char Tex[1000];
    fgets(Tex, 1000, stdin);

    int ind = 0;

    struct Node* root = paren_Tree(Tex, &ind);
    printf("%d\n", check_RedBlack_Tree(root));
    return 0;
}
    
    int validate_RedBlack_Tree(struct Node* node) {
        
        struct node *root;
        if (node == NULL)
            return 1;

        
        if (node->Color != 'R' && node->Color != 'B') {
            return 0;
        }

       
        if (node == root && node->Color != 'B') {
            return 0;
        }

       
        if (node->Color == 'R' && ((node->Lef != NULL && node->Lef->Color == 'R') || (node->Righ != NULL && node->Righ->Color == 'R'))) {
            return 0;
        }

       
        int left_Black_Height = validate_RedBlack_Tree(node->Lef);
        int right_Black_Height = validate_RedBlack_Tree(node->Righ);

        if (left_Black_Height == -1 || right_Black_Height == -1 || left_Black_Height != right_Black_Height) {
            return -1;
        }

        if (node->Color == 'B') {
            return left_Black_Height + 1;
        } else {
            return left_Black_Height;
        }
    }
    int check_RedBlack_Tree(struct Node* root) {

    return validate_RedBlack_Tree(root) == -1;
}


struct Node* paren_Tree(char Tex[], int* ind){
    char m = Tex[*ind];
    (*ind)++;

    if (m == '(') {
        m = Tex[*ind];
        (*ind)++;
        int Key = 0;
        char Color = 'B';
        int is_Negative = 0;

        if (m == '-') {
            is_Negative = 1;
            m = Tex[*ind];
            (*ind)++;
        }

        while (m >= '0' && m <= '9') {
            Key = Key * 10 + m - '0';
            m = Tex[*ind];
            (*ind)++;
        }

        if (is_Negative) {
            Key = -Key;
        }

        if (m == ' ') {
            m = Tex[*ind];
            (*ind)++;

            if (m == 'R') {
                Color = 'R';
            }
        }
        struct Node* node = CREATE_Node(Key, Color);
        node->Lef = paren_Tree(Tex, ind);
        node->Righ = paren_Tree(Tex, ind);
        m = Tex[*ind];
        (*ind)++;
        return node;
    }
     else {
        return NULL;
    }
}
