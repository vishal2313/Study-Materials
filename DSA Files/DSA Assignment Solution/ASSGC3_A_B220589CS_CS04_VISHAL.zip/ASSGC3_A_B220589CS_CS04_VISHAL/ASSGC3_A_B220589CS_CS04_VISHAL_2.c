#include <stdio.h>
#include <stdlib.h>
#define MAX_nodes 100

struct Stack {
    int Top;
    int* arr;
    unsigned Capa;
};

struct Stack* create_Stack(unsigned Capa) {
    struct Stack* stack = (struct Stack*)malloc(sizeof(struct Stack));
    stack->Capa = Capa;
    stack->Top = -1;
    stack->arr = (int*)malloc(stack->Capa * sizeof(int));
    return stack;
}


int is_Empty(struct Stack* stack); 
void Push(struct Stack* stack, int thing);
int Pop(struct Stack* stack);
void DFS(int a, int N, int Graph[MAX_nodes][MAX_nodes], int Visited[MAX_nodes], struct Stack* stack);
void DFS_Transpose(int a, int N, int transposed_Graph[MAX_nodes][MAX_nodes], int Visited[MAX_nodes]);
int Number_Of_Strongly_Components(int N, int Graph[MAX_nodes][MAX_nodes]);

int main() {
    int N;
    scanf("%d", &N);

    int Graph[MAX_nodes][MAX_nodes];

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            scanf("%d", &Graph[i][j]);
        }
    }

    char choice;

    do {
        scanf(" %c", &choice);
        switch(choice) {
            case 't':
                printf("%d\n", 1); 
                break;
            case 'c':
                printf("%d\n", Number_Of_Strongly_Components(N, Graph));
                break;
            case 'x':
                break;
        }
    } 
    while(choice != 'x');
    return 0;
}



int is_Empty(struct Stack* stack) {
    return stack->Top == -1;
}

int Pop(struct Stack* stack) {
    if (is_Empty(stack))
        return -1; 
    return stack->arr[stack->Top--];
}

void Push(struct Stack* stack, int thing) {
    stack->arr[++stack->Top] = thing;
}


void DFS_Transpose(int a, int N, int transposed_Graph[MAX_nodes][MAX_nodes], int Visited[MAX_nodes]) {
    Visited[a] = 1;
    for (int i = 0; i < N; i++) {
        if (transposed_Graph[a][i] == 1 && !Visited[i]) {
            DFS_Transpose(i, N, transposed_Graph, Visited);
        }
    }
}

void DFS(int a, int N, int Graph[MAX_nodes][MAX_nodes], int Visited[MAX_nodes], struct Stack* stack) {
    Visited[a] = 1;
    for (int i = 0; i < N; i++) {
        if (Graph[a][i] == 1 && !Visited[i]) {
            DFS(i, N, Graph, Visited, stack);
        }
    }
    Push(stack, a);
}

int Number_Of_Strongly_Components(int N, int Graph[MAX_nodes][MAX_nodes]){
    int Visited[MAX_nodes] = {0};
    struct Stack* stack = create_Stack(N);

    
    for (int i = 0; i < N; i++) {
        if (!Visited[i]) {
            DFS(i, N, Graph, Visited, stack);
        }
    }

    
    int transposed_Graph[MAX_nodes][MAX_nodes];
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            transposed_Graph[j][i] = Graph[i][j];
        }
    }

    for (int i = 0; i < N; i++) {
        Visited[i] = 0;
    }

    int scc_count = 0;
    while (!is_Empty(stack)) {
        int a = Pop(stack);
        if (!Visited[a]) {
            DFS_Transpose(a, N, transposed_Graph, Visited);
            scc_count++;
        }
    }

    free(stack->arr);
    free(stack);
    return scc_count;
}

