#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int Dest;
    struct Node* Next;
} Node;

typedef struct list {
    int v;
    struct list* Next;
} List;

typedef struct Graph {
    int V;
    Node** adj_List;
} Graph;



List* Create(int k) {
    List* x = (List*)malloc(sizeof(List));
    x->v = k;
    x->Next = NULL;
    return x;
}

Node* create_Node(int Dest) {
    Node* new_Node = (Node*)malloc(sizeof(Node));
    new_Node->Dest = Dest;
    new_Node->Next = NULL;
    return new_Node;
}


Graph* create_Graph(int V) {
    Graph* graph = (Graph*)malloc(sizeof(Graph));
    graph->V = V;
    graph->adj_List = (Node**)malloc((V + 1) * sizeof(Node));

    for (int i = 1; i <= V; ++i)
        graph->adj_List[i] = NULL;

    return graph;
}

void add_Edge(Graph* graph, int src, int Dest) {
    
    Node* new_Node = create_Node(Dest);
    new_Node->Next = graph->adj_List[src];
    graph->adj_List[src] = new_Node;
}


void DFS_Until(int v, Graph* graph, int Visited[]) {
    Visited[v] = 1;
    Node* Temp = graph->adj_List[v];

    while (Temp) {
        int adj_Vertex = Temp->Dest;
        if (!Visited[adj_Vertex])
            DFS_Until(adj_Vertex, graph, Visited);
        Temp = Temp->Next;
    }
}


void DFS_Until2(int v, Graph* graph, int Visited[], int* count) {
    Visited[v] = 1;
    Node* Temp = graph->adj_List[v];

    while (Temp) {
        int adj_Vertex = Temp->Dest;
        if (!Visited[adj_Vertex]) {
            (*count)++;
            DFS_Until2(adj_Vertex, graph, Visited, count);
        }
        Temp = Temp->Next;
    }
}

int NoOfconnectedComponents(Graph* graph) ;
void sizesofcomponents(Graph* graph) ;
void noOfBridges(Graph* graph, int i, int* Low, int* Step, int* Visited, int* C, int P, int* T);
void noOfArticulation(Graph* graph, int i, int* Low, int* Step, int* ap, int* Visited, int P, int* T);

int main() {
    int V, i, j, C;
    char SRR[1000];
    int ARR[100];
    scanf("%d", &V);

    Graph* graph = create_Graph(V);

    for (i = 0; i < V; i++) {
        scanf(" %[^\n]s", SRR);
        C = 0;
        j = 0;
        while (SRR[j] != '\0') {
            int num = 0;
            while (SRR[j] >= '0' && SRR[j] <= '9') {
                num = num * 10 + (SRR[j] - '0');
                j++;
            }
            ARR[C++] = num;
            if (SRR[j] == ' ') {
                j++;
           
        }
         }
    for (j = 1; j < C; j++) {
        add_Edge(graph, i + 1, ARR[j]);
    }
}

char choice;
while (1) {

    scanf(" %c", &choice);
    if (choice == 'n') {
        printf("%d\n", NoOfconnectedComponents(graph));
    } 
    else if (choice == 's') {
        sizesofcomponents(graph);
    } 
    else if (choice == 'b') {
        int Visited[100];
        for (i = 1; i <= V; i++) {
            Visited[i] = 0;
        }
        int C = 0;
        int Low[V + 1];
        int Step[V + 1];
        int T = 1;
        for (i = 1; i <= V; i++) {
            if (!Visited[i]) {
                T = 1;
                noOfBridges(graph, i, Low, Step, Visited, &C, -1, &T);
            }
        }
        (C != 0) ? printf("%d\n", C) : printf("-1\n");
    } 
    else if (choice == 'a') {
        int ap[V + 1];
        int Visited[100];
        for (i = 1; i <= V; i++) {
            Visited[i] = 0;
            ap[i] = 0;
        }
        int C = 0;
        int Low[V + 1];
        int Step[V + 1];
        int T = 1;
        for (i = 1; i <= V; i++) {
            if (!Visited[i]) {
                noOfArticulation(graph, i, Low, Step, ap, Visited, -1, &T);
            }
        }
        for (i = 1; i <= V; i++) {
            if (ap[i] == 1) {
                C++;
            }
        }
        (C != 0) ? printf("%d\n", C) : printf("-1\n");
    } 
    else if (choice == 't') {
        exit(0);
    }
}

return 1;
}

int NoOfconnectedComponents(Graph* graph) {
    int V = graph->V;
    int* Visited = (int*)malloc((V + 1) * sizeof(int));
    int count = 0;

    for (int v = 1; v <= V; ++v)
        Visited[v] = 0;

    for (int v = 1; v <= V; ++v) {
        if (!Visited[v]) {
            DFS_Until(v, graph, Visited);
            ++count;
        }
    }

    free(Visited);
    return count;
}


void sizesofcomponents(Graph* graph) {
    int V = graph->V;
    int* Visited = (int*)malloc((V + 1) * sizeof(int));
    List* Li = NULL;

    for (int v = 1; v <= V; ++v)
        Visited[v] = 0;

    for (int v = 1; v <= V; ++v) {
        if (!Visited[v]) {
            int count = 0;
            DFS_Until2(v, graph, Visited, &count);
            List* x = Create(count + 1);
            List* previous = NULL;
            List* current = Li;

            while (current && current->v <= x->v) {
                previous = current;
                current = current->Next;
            }

            if (previous == NULL) {
                x->Next = Li;
                Li = x;
            } else {
                previous->Next = x;
                x->Next = current;
            }
        }
    }
    List* Cu = Li;
    while (Cu) {
        printf("%d ", Cu->v);
        Cu = Cu->Next;
    }
    printf("\n");
    free(Visited);
}

void noOfBridges(Graph* graph, int i, int* Low, int* Step, int* Visited, int* C, int P, int* T) {
    Visited[i] = 1;
    Low[i] = *T;
    Step[i] = *T;
    (*T)++;
    Node* Pt = graph->adj_List[i];
    while (Pt != NULL) {
        if (Pt->Dest == P) {
            Pt = Pt->Next;
            continue;
        }
        if (!Visited[Pt->Dest]) {
            noOfBridges(graph, Pt->Dest, Low, Step, Visited, C, i, T);
            if (Low[i] > Low[Pt->Dest])
                Low[i] = Low[Pt->Dest];
            if (Low[Pt->Dest] > Step[i])
                (*C) = (*C) + 1;
        } else {
            if (Low[i] > Low[Pt->Dest])
                Low[i] = Low[Pt->Dest];
        }

        Pt = Pt->Next;
    }
}

void noOfArticulation(Graph* graph, int i, int* Low, int* Step, int* ap, int* Visited, int P, int* T) {
    int Child = 0;
    Visited[i] = 1;
    Low[i] = *T;
    Step[i] = *T;
    (*T)++;
    Node* Pt = graph->adj_List[i];
    while (Pt != NULL) {
        if (!Visited[Pt->Dest]) {
            Child++;
            noOfArticulation(graph, Pt->Dest, Low, Step, ap, Visited, i, T);
            if (Low[i] > Low[Pt->Dest])
                Low[i] = Low[Pt->Dest];
            if (Low[Pt->Dest] >= Step[i] && P != -1) {
                ap[i] = 1;
            }
        } else if (Pt->Dest != P) {
            if (Low[i] > Step[Pt->Dest])
                Low[i] = Step[Pt->Dest];
        }
        Pt = Pt->Next;
    }
    if (Child > 1 && P == -1) {
        ap[i] = 1;
    }
}

