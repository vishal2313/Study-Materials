#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

struct Node {
    int dest;
    struct Node* next;
};

struct List {
    struct Node* head;
};

struct Graph {
    int V;
    struct List* array;
};

struct Node* new_Node(int dest) {
    struct Node* new_Node = (struct Node*)malloc(sizeof(struct Node));
    new_Node->dest = dest;
    new_Node->next = NULL;
    return new_Node;
}

struct Graph* create_Graph(int V) {
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph));
    graph->V = V;

    graph->array = (struct List*)malloc(V * sizeof(struct List));

    for (int i = 0; i < V; ++i)
        graph->array[i].head = NULL;

    return graph;
}


void add_Edge(struct Graph* graph, int src, int dest) { 
    struct Node* newNodePtr = new_Node(dest);
    newNodePtr->next = graph->array[src].head;
    graph->array[src].head = newNodePtr;
}

void print_AllPaths_Util(struct Graph* graph, int u, int d, bool visited[], int path[], int path_index, int* count) {
    
    visited[u] = true;
    path[path_index] = u;
    path_index++;

    if (u == d) {
        for (int i = 0; i < path_index; i++) {
            printf("%d ", path[i]);
            (*count)++;
        }
        printf("\n");
    }
    else 
    {
        struct Node* pCrawl = graph->array[u].head;
        while (pCrawl != NULL) {
            if (!visited[pCrawl->dest])
                print_AllPaths_Util(graph, pCrawl->dest, d, visited, path, path_index, count);
            pCrawl = pCrawl->next;
        }
    }


    path_index--;
    visited[u] = false;
}


void print_AllPaths(struct Graph* graph, int s, int d) {
    bool* visited = (bool*)malloc(graph->V * sizeof(bool));
    int* path = (int*)malloc(graph->V * sizeof(int));
    int path_index = 0; 

    for (int i = 0; i < graph->V; i++)
        visited[i] = false;
    int count = 0;
    
    print_AllPaths_Util(graph, s, d, visited, path, path_index, &count);
    if (count == 0)
    {
        printf("-1\n");
    }
}

struct Node* reverse(struct Node* head)
{
    if (head == NULL)
    {
        return NULL;
    }
    struct Node* pre = NULL;
    struct Node* cu = head;
    struct Node* nn;
    while (cu != NULL)
    {
        nn = cu->next;
        cu->next = pre;
        pre = cu;
        cu = nn;
    }
    return pre;
}

bool isCyclicUtil(struct Graph* graph, int v, bool visited[], int parent) {
    visited[v] = true;
    struct Node* pCrawl = graph->array[v].head;
    while (pCrawl != NULL) {
        int dest = pCrawl->dest;
        if (!visited[dest]) {
            if (isCyclicUtil(graph, dest, visited, v))
                return true;
        }
        else if (dest != parent)
            return true;
        pCrawl = pCrawl->next;
    }
    return false;
}

bool isCyclic(struct Graph* graph) {
    bool* visited = (bool*)malloc(graph->V * sizeof(bool));
    for (int i = 0; i < graph->V; i++)
        visited[i] = false;
    for (int i = 0; i < graph->V; i++)
        if (!visited[i] && isCyclicUtil(graph, i, visited, -1))
            return true;
    return false;
}

void DFS_Util(struct Graph* graph, int v, bool visited[]) {
    visited[v] = true;

    struct Node* pCrawl = graph->array[v].head;
    while (pCrawl != NULL) {
        int dest = pCrawl->dest;
        if (!visited[dest])
            DFS_Util(graph, dest, visited);
        pCrawl = pCrawl->next;
    }
}
bool isConnected(struct Graph* graph) {
    bool* visited = (bool*)malloc(graph->V * sizeof(bool));
    for (int i = 0; i < graph->V; i++)
        visited[i] = false;
    int count = 0;
    for (int i = 0; i < graph->V; i++) {
        if (!visited[i]) {
            DFS_Util(graph, i, visited);
            count++;
        }
    }
    return count == 1; 
}

bool has_Isolated_Vertices(struct Graph* graph) {
    for (int i = 0; i < graph->V; i++) {
        if (graph->array[i].head == NULL)
            return true;
    }
    return false;
}

int isvalidTree(struct Graph* graph) {
    if (isCyclic(graph))
        return -1; 
    if (!isConnected(graph))
        return -1; 
    if (has_Isolated_Vertices(graph))
        return -1; 
    return 1; 

}


int main() {
    int V, i, j, c;
    int cou = 0;
    char s[1000];
    int a[100];
    scanf("%d", &V);
    struct Graph* graph = create_Graph(V);
    for (i = 0; i < V; i++)
    {
        scanf(" %[^\n]s", s);
        c = 0;
        j = 0;
        while (s[j] != '\0')
        {
            int num = 0;
            while (s[j] >= '0' && s[j] <= '9')
            {
                num = num * 10 + (s[j] - '0');
                j++;

            }
            a[c++] = num;
            if (s[j] == ' ')
            {
                j++;
            }

        }
        for (j = 1; j < c; j++)
        {
            add_Edge(graph, i, a[j]);
        }
        graph->array[i].head = reverse(graph->array[i].head);
    }

    int so, d;
    char ch;
    while (1)
    {
        scanf(" %c", &ch);
        if (ch == 'a')
        {
            scanf("%d %d", &so, &d);
            print_AllPaths(graph, so, d);
        }
        else if (ch == 't')
        {
            printf("%d\n", isvalidTree(graph));
        }
        else if (ch == 'x')
        {
            exit(0);
        }
    }
    return 1;
}
