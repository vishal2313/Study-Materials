#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#define max_size 1000000

struct Node
{
    int value;
    struct Node *l, *r;
};

void PostOrder(struct Node *Root);
struct Node *createTree(int Inorder[], int Preorder[], int inStart, int inEnd, int *preIndex);
void zig_zag(struct Node *Root);
void level_Max(struct Node *Root);
int Diameter(struct Node *Root);
int Height(struct Node *Root);
int LeftLeafSum(struct Node *Root, int isLeft);



int main()
 {
    int n;
    scanf("%d", &n);

    int Inorder[max_size];
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &Inorder[i]);
    }

    int Preorder[max_size];
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &Preorder[i]);
    }

    int preIndex = 0;
    struct Node *Root = createTree(Inorder, Preorder, 0, n - 1, &preIndex);

    while (1)
    {
        char character;
        scanf(" %c", &character);

        if (character == 'p')
        {
            PostOrder(Root);
            printf("\n");
        }

        else if (character == 'm')
        {
            level_Max(Root);
            printf("\n");
        }
        else if (character == 'z')
        {
            zig_zag(Root);
            printf("\n");
        }

        else if (character == 's')
        {
            printf("%d\n", LeftLeafSum(Root, 1));
        }

        else if (character == 'd')
        {
            printf("%d\n", Diameter(Root));
        }

        else if (character == 'e')
        {
            break;
        }
    }

    free(Root);

    return 0;
}



struct Node *createTree(int Inorder[], int Preorder[], int inStart, int inEnd, int *preIndex)
{
    if (inStart > inEnd)
    {
        return NULL;
    }

    struct Node *Root = (struct Node *)malloc(sizeof(struct Node));
    if (!Root)
    {
        perror("Memory allocation error");
        exit(EXIT_FAILURE);
    }

    Root->value = Preorder[(*preIndex)++];

    int inIndex;
    for (inIndex = inStart; inIndex <= inEnd; inIndex++)
    {
        if (Inorder[inIndex] == Root->value)
        {
            break;
        }
    }

    Root->l = createTree(Inorder, Preorder, inStart, inIndex - 1, preIndex);
    Root->r = createTree(Inorder, Preorder, inIndex + 1, inEnd, preIndex);

    return Root;
}

void PostOrder(struct Node *Root)
{
    if (Root)
    {
        PostOrder(Root->l);
        PostOrder(Root->r);
        printf("%d ", Root->value);
    }
}

void zig_zag(struct Node *Root)
{
    if (!Root)
    {
        return;
    }

    struct Node **Queue = (struct Node *)malloc(1000000 * sizeof(struct Node));
    if (!Queue)
    {
        perror("Memory allocation error");
        exit(EXIT_FAILURE);
    }

    int Front = -1, Rear = -1;
    int Level = 0;

    Queue[++Rear] = Root;

    while (Front != Rear)
    {
        int size = Rear - Front;
        int *level_Nodes = (int *)malloc(size * sizeof(int));
        if (!level_Nodes)
        {
            perror("Memory allocation error");
            exit(EXIT_FAILURE);
        }

        for (int i = 0; i < size; i++)
        {
            struct Node *node = Queue[++Front];
            level_Nodes[i] = node->value;

            if (node->l)
            {
                Queue[++Rear] = node->l;
            }
            if (node->r)
            {
                Queue[++Rear] = node->r;
            }
        }

        if (Level % 2 == 1)
        {
            for (int i = size - 1; i >= 0; i--)
            {
                printf("%d ", level_Nodes[i]);
            }
        }
        else
        {
            for (int i = 0; i < size; i++)
            {
                printf("%d ", level_Nodes[i]);
            }
        }
        Level++;

        free(level_Nodes);
    }

    free(Queue);
}

void level_Max(struct Node *Root)
{
    if (!Root)
    {
        return;
    }

    struct Node **Queue = (struct Node *)malloc(1000000 * sizeof(struct Node));
    if (!Queue)
    {
        perror("Memory allocation error");
        exit(EXIT_FAILURE);
    }

    int Front = -1, Rear = -1;

    Queue[++Rear] = Root;

    while (Front != Rear)
    {
        int size = Rear - Front;
        int level_Max = INT_MIN;

        for (int i = 0; i < size; i++)
        {
            struct Node *node = Queue[++Front];
            level_Max = (node->value > level_Max) ? node->value : level_Max;

            if (node->l)
            {
                Queue[++Rear] = node->l;
            }
            if (node->r)
            {
                Queue[++Rear] = node->r;
            }
        }

        printf("%d ", level_Max);
    }

    free(Queue);
}

int Diameter(struct Node *Root)
{
    if (!Root)
    {
        return 0;
    }

    int left_Height = Height(Root->l);
    int right_Height = Height(Root->r);

    int leftDiameter = Diameter(Root->l);
    int rightDiameter = Diameter(Root->r);

    return (left_Height + right_Height + 1 > leftDiameter && left_Height + right_Height + 1 > rightDiameter)
               ? left_Height + right_Height + 1
           : (leftDiameter > rightDiameter) ? leftDiameter
                                            : rightDiameter;
}

int Height(struct Node *Root)
{
    if (!Root)
    {
        return 0;
    }

    int left_Height = Height(Root->l);
    int right_Height = Height(Root->r);

    return (left_Height > right_Height) ? left_Height + 1 : right_Height + 1;
}

int LeftLeafSum(struct Node *Root, int isLeft)
{
    if (!Root)
    {
        return 0;
    }

    if (!Root->l && !Root->r && isLeft)
    {
        return Root->value;
    }

    int left_Sum = LeftLeafSum(Root->l, 1);
    int right_Sum = LeftLeafSum(Root->r, 0);

    return left_Sum + right_Sum;
}

 
