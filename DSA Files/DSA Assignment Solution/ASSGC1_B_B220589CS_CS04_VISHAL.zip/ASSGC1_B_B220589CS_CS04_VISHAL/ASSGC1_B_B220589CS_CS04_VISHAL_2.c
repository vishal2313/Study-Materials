#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <limits.h>

struct Node
{
    int val;
    struct Node *l;
    struct Node *r;
};

struct Node *create_Tree(char *par_rep, int *ind);
void level_Order(struct Node *Root);
void rightView_Until(struct Node *Root, int Level, int *max_level);
int isBST_Until(struct Node *Root, int Min, int Max);
int sum_Tree(struct Node *Root);
int is_BST(struct Node *Root);
void right_View(struct Node *Root);
int max_SumBST(struct Node *Root);


int main(void)
{
    char par_rep[1000];
    fgets(par_rep, sizeof(par_rep), stdin);

    int ind = 0;
    struct Node *Root = create_Tree(par_rep, &ind);

    while (1)
    {
        char input;
        scanf(" %c", &input);

        if (input == 'l')
        {
            level_Order(Root);
            printf("\n");
        }
        else if (input == 'r')
        {
            right_View(Root);
            printf("\n");
        }
        else if (input == 'm')
        {
            printf("%d\n", max_SumBST(Root));
        }
        
          else if (input == 'e')
        {
            break;
        }
    }

    return 0;
}





struct Node *create_Tree(char *par_rep, int *ind)
{
    if (par_rep[*ind] == '\0')
    {
        return NULL;
    }

    struct Node *node = NULL;

    if (isdigit(par_rep[*ind]) || par_rep[*ind] == '-')
    {
        int val = 0;
        while (isdigit(par_rep[*ind]) || par_rep[*ind] == '-')
        {
            val = val * 10 + (par_rep[*ind] - '0');
            (*ind)++;
        }
        node = (struct Node *)malloc(sizeof(struct Node));
        node->val = val;
        node->l = node->r = NULL;
    }

    if (par_rep[*ind] == '(')
    {
        (*ind)++;
        node->l = create_Tree(par_rep, ind);
    }

    if (par_rep[*ind] == ')')
    {
        (*ind)++;
        return node;
    }

    if (par_rep[*ind] == '(')
    {
        (*ind)++;
        node->r = create_Tree(par_rep, ind);
    }

    if (par_rep[*ind] == ')')
    {
        (*ind)++;
        return node;
    }

    return node;
}

void level_Order(struct Node *Root)
{
    if (Root == NULL)
    {
        return;
    }

    struct Node *Queue[10000];
    int Front = 0, Rear = 0;
    Queue[Rear++] = Root;

    while (Front < Rear)
    {
        struct Node *curr = Queue[Front++];
        printf("%d ", curr->val);

        if (curr->l)
        {
            Queue[Rear++] = curr->l;
        }

        if (curr->r)
        {
            Queue[Rear++] = curr->r;
        }
    }
}

void rightView_Until(struct Node *Root, int Level, int *max_level)
{
    if (Root == NULL)
    {
        return;
    }

    if (*max_level < Level)
    {
        printf("%d ", Root->val);
        *max_level = Level;
    }

    rightView_Until(Root->r, Level + 1, max_level);
    rightView_Until(Root->l, Level + 1, max_level);
}

int isBST_Until(struct Node *Root, int Min, int Max)
{
    if (Root == NULL)
    {
        return 1;
    }

    if (Root->val < Min || Root->val > Max)
    {
        return 0;
    }

    return isBST_Until(Root->l, Min, Root->val - 1) && isBST_Until(Root->r, Root->val + 1, Max);
}

int sum_Tree(struct Node *Root)
{
    if (Root == NULL)
    {
        return 0;
    }

    return Root->val + sum_Tree(Root->l) + sum_Tree(Root->r);
}

int is_BST(struct Node *Root)
{
    return isBST_Until(Root, INT_MIN, INT_MAX);
}

void right_View(struct Node *Root)
{
    int max_level = 0;
    rightView_Until(Root, 1, &max_level);
}

int max_SumBST(struct Node *Root)
{
    if (Root == NULL)
    {
        return 0;
    }

    if (is_BST(Root))
    {
        return sum_Tree(Root);
    }

    return fmax(max_SumBST(Root->l), max_SumBST(Root->r));
}


