#include <stdio.h>
#include <stdlib.h>

struct Node
{
    int key;
    struct Node *next;
};

struct Node *CREATE_NODE(int key)
{
    struct Node *NEW_Node = (struct Node *)malloc(sizeof(struct Node));
    NEW_Node->key = key;
    NEW_Node->next = NULL;
    return NEW_Node;
}

int LIST_DELETE(struct Node **HEAD, int Index)
{
    if (*HEAD == NULL || Index < 1)
    {
        return -1;
    }

    if (Index == 1)
    {
        struct Node *Temp = *HEAD;
        *HEAD = (*HEAD)->next;
        int key = Temp->key;
        free(Temp);
        return key;
    }

    struct Node *Curr = *HEAD;
    for (int i = 1; i < Index - 1 && Curr != NULL; i++)
    {
        Curr = Curr->next;
    }

    if (Curr == NULL || Curr->next == NULL)
    {
        return -1;
    }

    struct Node *Temp = Curr->next;
    Curr->next = Temp->next;
    int key = Temp->key;
    free(Temp);
    return key;
}
void LIST_INSERT(struct Node **HEAD, struct Node *x)
{
    if (*HEAD == NULL)
    {
        *HEAD = x;
    }
    else
    {
        struct Node *Curr = *HEAD;
        while (Curr->next != NULL)
        {
            Curr = Curr->next;
        }
        Curr->next = x;
    }
}

void LIST_RDUPLICATE(struct Node **HEAD)
{
    struct Node *Curr = *HEAD;

    while (Curr != NULL)
    {
        struct Node *Runn = Curr;

        while (Runn->next != NULL)
        {
            if (Runn->next->key == Curr->key)
            {
                struct Node *Temp = Runn->next;
                Runn->next = Runn->next->next;
                free(Temp);
            }
            else
            {
                Runn = Runn->next;
            }
        }

        Curr = Curr->next;
    }
}
void LIST_DISPLAY(struct Node *HEAD)
{
    struct Node *Curr = HEAD;

    while (Curr != NULL)
    {
        printf("%d ", Curr->key);
        Curr = Curr->next;
    }

    printf("\n");
}

char LIST_PAL(struct Node *HEAD)
{
    struct Node *Slow = HEAD;
    struct Node *Fast = HEAD;
    struct Node *Prev = NULL;

    while (Fast != NULL && Fast->next != NULL)
    {
        struct Node *Temp = CREATE_NODE(Slow->key);
        Temp->next = Prev;
        Prev = Temp;

        Slow = Slow->next;
        Fast = Fast->next->next;
    }

    if (Fast != NULL)
    {
        Slow = Slow->next;
    }

    while (Slow != NULL)
    {
        if (Slow->key != Prev->key)
        {
            return 'N';
        }
        Slow = Slow->next;
        Prev = Prev->next;
    }

    return 'Y';
}

int main()
{
    struct Node *HEAD = NULL;

    char opera;
    int key, Index;

    do
    {
        scanf(" %c", &opera);

        switch (opera)
        {
        case 'a':
            scanf("%d", &key);
            LIST_INSERT(&HEAD, CREATE_NODE(key));
            break;
        case 'r':
            scanf("%d", &Index);
            key = LIST_DELETE(&HEAD, Index);
            if (key != -1)
            {
                printf("%d\n", key);
            }
            else
            {
                printf("-1\n");
            }
            break;
        case 'd':
            LIST_RDUPLICATE(&HEAD);
            LIST_DISPLAY(HEAD);
            break;
        case 'p':
            printf("%c\n", LIST_PAL(HEAD));
            break;
        case 's':
            LIST_DISPLAY(HEAD);
            break;
        }
    } while (opera != 'e');

    struct Node *Curr = HEAD;
    while (Curr != NULL)
    {
        struct Node *Temp = Curr;
        Curr = Curr->next;
        free(Temp);
    }

    return 0;
}
