#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAXIMUM_SIZE 1000000

int check_duplicate(char *arr);

int main()
{
    int n;
    char arr[MAXIMUM_SIZE];
    scanf("%d", &n);
    scanf("%s", arr);

    printf("%d\n", check_duplicate(arr));
}

int check_duplicate(char *arr)
{
    int peek = -1;
    char stack_ar[MAXIMUM_SIZE];

    for (int i = 0; arr[i] != '\0'; i++)
    {
        if (arr[i] == ')')
        {
            char topmost_Char = stack_ar[peek];
            peek--;
            int temp = 1;
            while (peek >= 0 && topmost_Char != '(')
            {
                if (topmost_Char == '+' || topmost_Char == '-' || topmost_Char == '*' || topmost_Char == '/'||topmost_Char == '^')
                 temp = 0;
                topmost_Char = stack_ar[peek];
                peek--;
            }
            if (temp == 1)
                return 1;
        }
        else
        {
            stack_ar[++peek] = arr[i];
        }
    }
    return 0;
}
