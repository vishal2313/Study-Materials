#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define MAX_VERTICES 100 


typedef struct Edge_Node {
    int Dest;
    double Weight;
    struct Edge_Node* Next;
} Edge_Node;


typedef struct Vertex_List {
    int vertex_Label;
    struct Edge_Node* Head;
} Vertex_List;


typedef struct Graph {
    int num_Vertices;
    struct Vertex_List* adj_Lists;
} Graph;


Graph* myCreate_Graph(int num_Vertices) {
    Graph* graph = (Graph*)malloc(sizeof(Graph));
    if (graph == NULL) {
      
        exit(EXIT_FAILURE);
    }
    graph->num_Vertices = num_Vertices;
    graph->adj_Lists = (Vertex_List*)malloc(num_Vertices * sizeof(Vertex_List));
    if (graph->adj_Lists == NULL) {
        free(graph);
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < num_Vertices; ++i) {
        graph->adj_Lists[i].vertex_Label = i + 1; 
        graph->adj_Lists[i].Head = NULL;
    }
    return graph;
}


void myAdd_Edge(Graph* graph, int srct, int Dest, double Weight) {
    Edge_Node* new_Node = (Edge_Node*)malloc(sizeof(Edge_Node));
    if (new_Node == NULL) {
        exit(EXIT_FAILURE);
    }
    new_Node->Dest = Dest;
    new_Node->Weight = Weight;
    new_Node->Next = graph->adj_Lists[srct - 1].Head; 
    graph->adj_Lists[srct - 1].Head = new_Node; 
}


void myReverse_Weights(Graph* graph) {
    for (int i = 0; i < graph->num_Vertices; i++) {
        Edge_Node* curr = graph->adj_Lists[i].Head;
        int count = 0;
        while (curr != NULL) {
            count++;
            curr = curr->Next;
        }
        
        
        double weights[count];
        
        
        curr = graph->adj_Lists[i].Head;
        for (int j = 0; j < count; j++) {
            weights[j] = curr->Weight;
            curr = curr->Next;
        }
        
        
        for (int j = 0; j < count / 2; j++) {
            double temp = weights[j];
            weights[j] = weights[count - j - 1];
            weights[count - j - 1] = temp;
        }
        
        
        curr = graph->adj_Lists[i].Head;
        for (int j = 0; j < count; j++) {
            curr->Weight = weights[j];
            curr = curr->Next;
        }
    }
}


int min_Distance(double Dist[], int spt_Set[], int V) {
    double min = INT_MAX;
    int min_index = -1;
    for (int v = 0; v < V; v++) {
        if (spt_Set[v] == 0 && Dist[v] <= min) {
            min = Dist[v];
            min_index = v;
        }
    }
    return min_index;
}


void my_Dijkstra(Graph* graph, int srct) {
    int V = graph->num_Vertices;
    double Dist[V + 1]; 
    int spt_Set[V + 1]; 

   
    for (int i = 1; i <= V; i++) {
        Dist[i] = INT_MAX;
        spt_Set[i] = 0;
    }

    
    Dist[srct] = 0; 

    
    for (int count = 0; count < V - 1; count++) {
       
        int u = min_Distance(Dist, spt_Set, V + 1); 
        
        spt_Set[u] = 1;
       
        Edge_Node* p_Crawl = graph->adj_Lists[u - 1].Head;
        while (p_Crawl != NULL) {
            int v = p_Crawl->Dest;
            if (!spt_Set[v] && Dist[u] != INT_MAX && Dist[u] + p_Crawl->Weight < Dist[v]) {
                Dist[v] = Dist[u] + p_Crawl->Weight;
            }
            p_Crawl = p_Crawl->Next;
        }
    }

   
    for (int i = 1; i <= V; i++) {
        printf("%.0f ", Dist[i]);
    }
    printf("\n");
}


int main() {
    int num_Vertices;
    scanf("%d", &num_Vertices);
    getchar(); 

    Graph* G = myCreate_Graph(num_Vertices);

    
    for (int i = 1; i <= num_Vertices; i++) {
        int Label;
        scanf("%d", &Label);
        getchar(); 
        int adj_Node;
        while (scanf("%d", &adj_Node) == 1) {
            myAdd_Edge(G, Label, adj_Node, 0); 
            char c = getchar();
            if (c == '\n' || c == EOF) 
                break;
        }
    }

    
    for (int i = 1; i <= num_Vertices; i++) {
        int Label;
        scanf("%d", &Label);
        getchar();
        Edge_Node* curr = G->adj_Lists[Label - 1].Head; 
        while (curr != NULL) {
            double Weight;
            scanf("%lf", &Weight);
            curr->Weight = Weight;
            curr = curr->Next;
            char c = getchar(); 
            if (c == '\n' || c == EOF) 
                break;
        }
    }

 
    myReverse_Weights(G);

    int srct;
    scanf("%d", &srct); 

  
    my_Dijkstra(G, srct);


    return 0;
}