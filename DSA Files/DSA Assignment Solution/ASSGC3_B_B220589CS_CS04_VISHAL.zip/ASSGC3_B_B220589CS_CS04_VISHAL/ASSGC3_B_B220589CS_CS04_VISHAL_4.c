#include <stdio.h>
#include <limits.h>

#define max 100

void Floyd_Warshall(int Graph[max][max], int num_of_Nodes);

int main() {
    int num_of_Nodes;
    scanf("%d", &num_of_Nodes);

    int Graph[max][max];
    for (int i = 0; i < num_of_Nodes; i++) {
        for (int j = 0; j < num_of_Nodes; j++) {
            scanf("%d", &Graph[i][j]);
        }
    }
    Floyd_Warshall(Graph, num_of_Nodes);
    return 0;
}

void Floyd_Warshall(int Graph[max][max], int num_of_Nodes) {
    int matrix[num_of_Nodes][num_of_Nodes];
    for (int i = 0; i < num_of_Nodes; i++) {
        for (int j = 0; j < num_of_Nodes; j++) {
            matrix[i][j] = Graph[i][j];
        }
    }
    for (int k = 0; k < num_of_Nodes; k++) {
        for (int i = 0; i < num_of_Nodes; i++) {
            for (int j = 0; j < num_of_Nodes; j++) {
                if (matrix[i][k] != -1 && matrix[k][j] != -1 && (matrix[i][k] + matrix[k][j] < matrix[i][j] || matrix[i][j] == -1)) {
                    matrix[i][j] = matrix[i][k] + matrix[k][j];
                }
            }
        }
    }
    for (int i = 0; i < num_of_Nodes; i++) {
        for (int j = 0; j < num_of_Nodes; j++) {
            printf("%d", matrix[i][j]);
            if (j < num_of_Nodes - 1) {
                printf(" ");
            }
        }
        printf("\n");
    }
}
