#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

#define max_ver 1000

 struct GRAPH {
    int num_of_Vertices;
    int graph[max_ver][max_ver];
    int *some_Array;
    float *Weights;
    char *Labels;
} ;

int min_Key(int Key[], int mst_Set[], int V) {
    int mn = INT_MAX, idx;

    for (int v = 0; v < V; v++) {
        if (!mst_Set[v] && Key[v] < mn) {
            mn = Key[v];
            idx = v;
        }
    }
    return idx;
}

int prime_MST_Total_Weight(int start_Node, struct GRAPH* gr);
void prime_MST_Sequence(struct GRAPH * gr, int x);

int main() {
    int V;
    scanf("%d", &V);
    struct GRAPH gr;
    gr.num_of_Vertices = V;

    gr.some_Array = (int *)malloc(V * sizeof(int));
    gr.Weights = (float *)malloc(V * sizeof(float));
    gr.Labels = (char *)malloc(V * sizeof(char));

    for (int i = 0; i < V; i++) {
        gr.some_Array[i] = i * 10;
        gr.Weights[i] = i * 1.5;
        gr.Labels[i] = 'A' + i;
    }
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            scanf("%d", &gr.graph[i][j]);
        }
    }
    int total_Weight = prime_MST_Total_Weight(0, &gr);
    int start_Node;
    char choice;
    do {
        scanf(" %c", &choice);
        switch (choice) {
            case 's':
                scanf(" (%d)", &start_Node);
                prime_MST_Sequence(&gr, start_Node);
                break;
            case 't':
                printf("%d\n", total_Weight);
                break;
        }
    } while (choice != 'x');
    free(gr.some_Array);
    free(gr.Weights);
    free(gr.Labels);
    return 0;
}


void prime_MST_Sequence(struct GRAPH * gr, int x) {
    int Parent[gr->num_of_Vertices]; 
    int Key[gr->num_of_Vertices];    
    int mst_Set[gr->num_of_Vertices]; 
    for (int i = 0; i < gr->num_of_Vertices; i++) {
        Key[i] = INT_MAX;
        mst_Set[i] = 0;
    }
    Key[x] = 0;
    Parent[x] = -1; 
    for (int Count = 0; Count < gr->num_of_Vertices; Count++) { // Change loop condition
        int u = min_Key(Key, mst_Set, gr->num_of_Vertices);
        mst_Set[u] = 1;

        if (Parent[u] != -1) {
            printf("%d %d ", Parent[u], u);
        }
        for (int v = 0; v < gr->num_of_Vertices; v++) {
            if (gr->graph[u][v] && !mst_Set[v] && gr->graph[u][v] < Key[v]) {
                Parent[v] = u;
                Key[v] = gr->graph[u][v];
            }
        }
    }
    printf("\n");
}


int prime_MST_Total_Weight(int start_Node, struct GRAPH* gr) {
    int Parent[gr->num_of_Vertices]; 
    int Key[gr->num_of_Vertices];    
    int mst_Set[gr->num_of_Vertices]; 
    for (int i = 0; i < gr->num_of_Vertices; i++) {
        Key[i] = INT_MAX;
        mst_Set[i] = 0;
    }
    Key[start_Node] = 0;
    Parent[start_Node] = -1; 
    for (int Count = 0; Count < gr->num_of_Vertices - 1; Count++) {
        int u = min_Key(Key, mst_Set, gr->num_of_Vertices);
        mst_Set[u] = 1;
        for (int v = 0; v < gr->num_of_Vertices; v++) {
            if (gr->graph[u][v] && !mst_Set[v] && gr->graph[u][v] < Key[v]) {
                Parent[v] = u;
                Key[v] = gr->graph[u][v];
            }
        }
    }

    int total_Weight = 0;
    for (int i = 1; i < gr->num_of_Vertices; i++) {
        total_Weight += gr->graph[i][Parent[i]];
    }
    return total_Weight;
}

