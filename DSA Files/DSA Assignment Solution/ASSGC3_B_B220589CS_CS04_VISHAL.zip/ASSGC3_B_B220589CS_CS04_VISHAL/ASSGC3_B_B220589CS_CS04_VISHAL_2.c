#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define MAX_VERTICES 100 

typedef struct Edge_Node {
    int Dest;
    double Weight;
    struct Edge_Node* Next;
    char Var1; 
} Edge_Node;

typedef struct Vertex_List {
    int vertex_Label;
    struct Edge_Node* Head;
    int vertex_Type;
} Vertex_List;

typedef struct Graph {
    int num_Vertices;
    struct Vertex_List* adj_Lists;
    char graph_Type;
} Graph;


void myAdd_Edge(Graph* graph, int src, int Dest, double Weight);
Graph* myCreate_Graph(int num_Vertices) ;
void myReverse_Weights(Graph* graph);
void myKruskal_MST(Graph* graph);
void myUnion_Sets(int parent[], int x, int y);
int myFind_Parent(int parent[], int i);


int main() {
    int num_Vertices;
    scanf("%d", &num_Vertices); 
    getchar(); 
    Graph* G = myCreate_Graph(num_Vertices);
    for (int i = 0; i < num_Vertices; i++) {
        int Label;
        scanf("%d", &Label);
        getchar(); 
        int adj_Node;
        while (scanf("%d", &adj_Node) == 1) {
            myAdd_Edge(G, Label, adj_Node, 0);
            char c = getchar();
            if (c == '\n' || c == EOF) 
                break;
        }
    }
    for (int i = 0; i < num_Vertices; i++) {
        int Label;
        scanf("%d", &Label);
        getchar(); 
        Edge_Node* current = G->adj_Lists[Label].Head;
        while (current != NULL) {
            double Weight;
            scanf("%lf", &Weight);
            current->Weight = Weight;
            current = current->Next;
            char c = getchar(); 
            if (c == '\n' || c == EOF) 
                break;
        }
    }
    myReverse_Weights(G);
    myKruskal_MST(G);
    return 0;
}


void myAdd_Edge(Graph* graph, int src, int Dest, double Weight) {
    Edge_Node* new_Node = (Edge_Node*)malloc(sizeof(Edge_Node));
    if (new_Node == NULL) {
        exit(EXIT_FAILURE);
    }
    new_Node->Dest = Dest;
    new_Node->Weight = Weight;
    new_Node->Next = graph->adj_Lists[src].Head;
    new_Node->Var1 = 'A';
    graph->adj_Lists[src].Head = new_Node;
}

Graph* myCreate_Graph(int num_Vertices) {
    Graph* graph = (Graph*)malloc(sizeof(Graph));
    if (graph == NULL) {
       // printf("Memory allocation failed.");
        exit(EXIT_FAILURE);
    }
    graph->num_Vertices = num_Vertices;
    graph->adj_Lists = (Vertex_List*)malloc(num_Vertices * sizeof(Vertex_List));
    if (graph->adj_Lists == NULL) {
        free(graph);
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < num_Vertices; ++i) {
        graph->adj_Lists[i].vertex_Label = i;
        graph->adj_Lists[i].Head = NULL;
        graph->adj_Lists[i].vertex_Type = i % 2;
    }
    graph->graph_Type = 'U'; 
    return graph;
}

void myReverse_Weights(Graph* graph) {
    for (int i = 0; i < graph->num_Vertices; i++) {
        Edge_Node* current = graph->adj_Lists[i].Head;
        int count = 0;
        while (current != NULL) {
            count++;
            current = current->Next;
        }
        
        double weights[count];
        
        current = graph->adj_Lists[i].Head;
        for (int j = 0; j < count; j++) {
            weights[j] = current->Weight;
            current = current->Next;
        }
       
        for (int j = 0; j < count / 2; j++) {
            double temp = weights[j];
            weights[j] = weights[count - j - 1];
            weights[count - j - 1] = temp;
        }
        
        current = graph->adj_Lists[i].Head;
        for (int j = 0; j < count; j++) {
            current->Weight = weights[j];
            current = current->Next;
        }
    }
}

void myUnion_Sets(int parent[], int x, int y) {
    int xset = myFind_Parent(parent, x);
    int yset = myFind_Parent(parent, y);
    parent[xset] = yset;
}

int myFind_Parent(int parent[], int i) {
    if (parent[i] == i)
        return i;
    return myFind_Parent(parent, parent[i]);
}

void myKruskal_MST(Graph* graph) {
    int parent[graph->num_Vertices];
    double minCost = 0;
   
    for (int i = 0; i < graph->num_Vertices; i++) {
        parent[i] = i;
    }

    int edge_count = 0;
    while (edge_count < graph->num_Vertices - 1) {
        double min = INT_MAX;
        int a = -1, b = -1;
        for (int i = 0; i < graph->num_Vertices; i++) {
            Edge_Node* current = graph->adj_Lists[i].Head;
            while (current != NULL) {
                int j = current->Dest;
                if (myFind_Parent(parent, i) != myFind_Parent(parent, j) && current->Weight < min) {
                    min = current->Weight;
                    a = i;
                    b = j;
                }
                current = current->Next;
            }
        }

        if (a != -1 && b != -1) {
            myUnion_Sets(parent, a, b);
            edge_count++;
            minCost += min;
        }
    }
    printf("%.0f\n", minCost);
}


