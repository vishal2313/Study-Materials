#include <stdio.h>
#include <stdlib.h>

#define max_size 200


typedef struct {
    int Table[max_size];
} Hash_Table;


void init_HashTable(Hash_Table *ht) ;
int hash_Function(int key);
void Insert(Hash_Table *ht, int key);
int Search(Hash_Table *ht, int key) ;
void print_Union(int A[], int m, int B[], int n);
void find_Intersection(int A[], int m, int B[], int n) ;
int print_Set_Difference(int A[], int m, int B[], int n) ;


int main() {
    int m, n;
    scanf("%d %d", &m, &n);
    getchar();

    int A[m], B[n];
    for (int i = 0; i < m; i++)
        scanf("%d", &A[i]);
    getchar(); 
    for (int i = 0; i < n; i++)
        scanf("%d", &B[i]);
    getchar(); 

    char choice[4];
    while (scanf("%s", choice) == 1) {
    
        char array1, array2;
        scanf(" %c %c", &array1, &array2);

        if (choice[0] == 'u') {
            if (array1 == 'A' && array2 == 'B')
                print_Union(A, m, B, n);
            else if (array1 == 'B' && array2 == 'A')
                print_Union(B, n, A, m);
        }
         else if (choice[0] == 'i') {
            if (array1 == 'A' && array2 == 'B')
                find_Intersection(B, n, A, m);
            else if (array1 == 'B' && array2 == 'A')
                find_Intersection(A, m, B, n);
        } 
        else if (choice[0] == 's') {
            if (array1 == 'A' && array2 == 'B')
                print_Set_Difference(A, m, B, n);
            else if (array1 == 'B' && array2 == 'A')
                print_Set_Difference(B, n, A, m);
        }
         if (choice[0] == 'e') 
            break;
    }

    return 0;
}


void init_HashTable(Hash_Table *ht) {
    for (int i = 0; i < max_size; i++)
        ht->Table[i] = -1;
}


int hash_Function(int key) {
    return key % max_size;
}


void Insert(Hash_Table *ht, int key) {
    int index = hash_Function(key);
    while (ht->Table[index] != -1) {
        if (ht->Table[index] == key)
            return; 
        index = (index + 1) % max_size; 
    }
    ht->Table[index] = key;
}


int Search(Hash_Table *ht, int key) {
    int index = hash_Function(key);
    while (ht->Table[index] != -1) {
        if (ht->Table[index] == key)
            return 1;
        index = (index + 1) % max_size; 
    }
    return 0;
}

void print_Union(int A[], int m, int B[], int n) {
    Hash_Table ht;
    init_HashTable(&ht);

    
    for (int i = 0; i < m; i++) {
        if (!Search(&ht, A[i])) {
            Insert(&ht, A[i]);
             printf("%d ", A[i]);
        }
    }

    
    for (int i = 0; i < n; i++) {
        if (!Search(&ht, B[i])) {
            Insert(&ht, B[i]);
              printf("%d ", B[i]);
        
        }
    }
    
    printf("\n");

}


void find_Intersection(int A[], int m, int B[], int n) {
    Hash_Table ht;
    init_HashTable(&ht);

    
    for (int i = 0; i < m; i++)
        Insert(&ht, A[i]);


    for (int i = 0; i < n; i++) {
        
        if (Search(&ht, B[i])) {
            printf("%d ", B[i]);
        
            ht.Table[hash_Function(B[i])] = -1;
        }
    }
    printf("\n");
}


int print_Set_Difference(int A[], int m, int B[], int n) {
    Hash_Table ht;
    init_HashTable(&ht);
    int difference_found = 0;
    for (int i = 0; i < n; i++)
        Insert(&ht, B[i]);

    for (int i = 0; i < m; i++) {
        if (!Search(&ht, A[i])){
            printf("%d ", A[i]);
            difference_found = 1;
     }
    }
    if(!difference_found){
        printf("-1");
    }
    printf("\n");
}

