#include <stdio.h>
#include <stdlib.h>


typedef struct Node
{
    int key;
    struct Node *next;
} Node;


Node *create_Node(int key);
void Insert(Node **hash_Table, int key, int table_Size);
void delete_Key(Node **hash_Table, int key, int table_Size);
void Search(Node **hash_Table, int key, int table_Size);
void print_Elements_In_Chain(Node **hash_Table, int index);
void Update(Node **hash_Table, int old_Key, int new_Key, int table_Size);


int main()
{
    int table_Size;
    scanf("%d", &table_Size);
    Node **hash_Table = (Node *)malloc(table_Size * sizeof(Node));
    if (*hash_Table == NULL)
    {
        printf("Memory allocation failed\n");
        return EXIT_FAILURE;
    }
    for (int i = 0; i < table_Size; i++)
    {
        hash_Table[i] = NULL;
    }

    int key, old_Key, new_Key;
    char operation;
    
    while(1){
    scanf(" %c", &operation);
    switch (operation)
    {

    case 'i':
        scanf("%d", &key);
        Insert(hash_Table, key, table_Size);
        break;

    case 's':
        scanf("%d", &key);
        Search(hash_Table, key, table_Size);
        break;

    case 'd':
        scanf("%d", &key);
        delete_Key(hash_Table, key, table_Size);
        break;

    case 'u':
        scanf("%d %d", &old_Key, &new_Key);
        Update(hash_Table, old_Key, new_Key, table_Size);
        break;

    case 'p':
        scanf("%d", &key);
        print_Elements_In_Chain(hash_Table, key);
        break;

    case 'e':
        break;
    }
    }

    for (int i = 0; i < table_Size; i++)
    {
        Node *curr = hash_Table[i];
        while (curr != NULL)
        {
            Node *temp = curr;
            curr = curr->next;
            free(temp);
        }
    }
    free(hash_Table);

    return 0;
}




Node *create_Node(int key)
{
    Node *new_Node = (Node *)malloc(sizeof(Node));
    if (new_Node == NULL)
    {
        printf("Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    new_Node->key = key;
    new_Node->next = NULL;
    return new_Node;
}


void Insert(Node **hash_Table, int key, int table_Size)
{
    int index = key % table_Size;
    Node *new_Node = create_Node(key);
    if (hash_Table[index] == NULL)
    {
        hash_Table[index] = new_Node;
    }
    else
    {
        Node *curr = hash_Table[index];
        Node *prev = NULL;
        while (curr != NULL && curr->key < key)
        {
            prev = curr;
            curr = curr->next;
        }
        if (curr == NULL)
        {
            prev->next = new_Node;
        }
        else
        {
            if (prev == NULL)
            {
                new_Node->next = curr;
                hash_Table[index] = new_Node;
            }
            else
            {
                prev->next = new_Node;
                new_Node->next = curr;
            }
        }
    }
}


void delete_Key(Node **hash_Table, int key, int table_Size)
{
    int index = key % table_Size;
    Node *curr = hash_Table[index];
    Node *prev = NULL;
    int pos = 1;
    while (curr != NULL && curr->key != key)
    {
        prev = curr;
        curr = curr->next;
        pos++;
    }
    if (curr == NULL)
    {
        printf("-1\n");
    }
    else
    {
        if (prev == NULL)
        {
            hash_Table[index] = curr->next;
        }
        else
        {
            prev->next = curr->next;
        }
        free(curr);
        printf("%d %d\n", index, pos);
    }
}


void Search(Node **hash_Table, int key, int table_Size)
{
    int index = key % table_Size;
    Node *curr = hash_Table[index];
    int pos = 1;
    while (curr != NULL && curr->key != key)
    {
        curr = curr->next;
        pos++;
    }
    if (curr == NULL)
    {
        printf("-1\n");
    }
    else
    {
        printf("%d %d\n", index, pos);
    }
}

void print_Elements_In_Chain(Node **hash_Table, int index)
{
    Node *curr = hash_Table[index];
    if (curr == NULL)
    {
        printf("-1\n");
        return;
    }
    while (curr != NULL)
    {
        printf("%d ", curr->key);
        curr = curr->next;
    }
    printf("\n");
}

void Update(Node **hash_Table, int old_Key, int new_Key, int table_Size)
{
    delete_Key(hash_Table, old_Key, table_Size);
    Insert(hash_Table, new_Key, table_Size);
}

