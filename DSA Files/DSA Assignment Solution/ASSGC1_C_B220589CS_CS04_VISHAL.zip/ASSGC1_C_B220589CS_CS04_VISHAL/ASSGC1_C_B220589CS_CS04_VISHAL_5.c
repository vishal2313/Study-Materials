#include <stdio.h>
#define MAX 1000001

int count_Distinct_In_Windows(int array[], int N, int K);

int main()
{
    int N, K;
    scanf("%d %d", &N, &K);

    int array[MAX];
    for (int i = 0; i < N; i++)
    {
        scanf("%d", &array[i]);
    }

    count_Distinct_In_Windows(array, N, K);
    return 0;
}

int count_Distinct_In_Windows(int array[], int N, int K)
{

    int dist_count = 0;
    int windo[MAX] = {0};

    for (int i = 0; i < K; i++)
    {
        if (windo[array[i]] == 0)
        {
            dist_count++;
        }
        windo[array[i]]++;
    }

    printf("%d ", dist_count);

    for (int i = K; i < N; i++)
    {

        windo[array[i - K]]--;

        if (windo[array[i - K]] == 0)
        {
            dist_count--;
        }

        if (windo[array[i]] == 0)
        {
            dist_count++;
        }
        windo[array[i]]++;

        printf("%d ", dist_count);
    }

    printf("\n");
}
